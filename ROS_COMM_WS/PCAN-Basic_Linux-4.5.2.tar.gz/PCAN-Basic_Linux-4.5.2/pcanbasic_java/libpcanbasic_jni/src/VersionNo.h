#define VERSION_MAJOR		4
#define VERSION_MINOR		5
#define VERSION_PATCH		0
#define VERSION_BUILD		0

#define FILEVER 4,5,0,0
#define STRFILEVER "4.5.0.0"
#define STRPRODUCTVER "4.5"
#define COPYRIGHT "Copyright © 2021 PEAK-System Technik GmbH"
