#define VERSION_MAJOR		4
#define VERSION_MINOR		4
#define VERSION_PATCH		0
#define VERSION_BUILD		1

#define FILEVER 4,4,0,1
#define STRFILEVER "4.4.0.1"
#define STRPRODUCTVER "4.4"
#define COPYRIGHT "Copyright © 2020 PEAK-System Technik GmbH"
